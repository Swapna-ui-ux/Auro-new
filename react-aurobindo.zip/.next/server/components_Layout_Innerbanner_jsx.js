exports.id = "components_Layout_Innerbanner_jsx";
exports.ids = ["components_Layout_Innerbanner_jsx"];
exports.modules = {

/***/ "./components/Layout/Innerbanner.jsx":
/*!*******************************************!*\
  !*** ./components/Layout/Innerbanner.jsx ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\Swapna\\Desktop\\June-works\\react-aurobindo\\components\\Layout\\Innerbanner.jsx";

const propTypes = {};
const defaultProps = {};

const Innerbanner = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
      id: "page-title",
      className: "page-title-parallax page-title-dark",
      style: {
        backgroundImage: `url("img/banners/Investors-Banner-Img.jpg")`
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container clearfix",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
          children: "DELIVERING ROBUST FINANCIALS"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 10,
          columnNumber: 5
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h6", {
          children: ["We believe that execution is everything ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 11,
            columnNumber: 49
          }, undefined), "and always challenge ourselves to deliver superior performance"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 11,
          columnNumber: 5
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ol", {
          className: "breadcrumb",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: "breadcrumb-item",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
              href: "#",
              children: "Home"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 13,
              columnNumber: 38
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 13,
            columnNumber: 6
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: "breadcrumb-item",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
              href: "#",
              children: "Investors"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 14,
              columnNumber: 38
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 14,
            columnNumber: 6
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: "breadcrumb-item",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
              href: "#",
              children: "Results, Reports & Presentations"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 15,
              columnNumber: 38
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 6
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: "breadcrumb-item active",
            "aria-current": "page",
            children: "Results Announcements"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 6
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 5
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 4
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 8
    }, undefined)
  }, void 0, false);
};

Innerbanner.propTypes = propTypes;
Innerbanner.defaultProps = defaultProps;
/* harmony default export */ __webpack_exports__["default"] = (Innerbanner);

/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yZWFjdC1hdXJvYmluZG8vLi9jb21wb25lbnRzL0xheW91dC9Jbm5lcmJhbm5lci5qc3giXSwibmFtZXMiOlsicHJvcFR5cGVzIiwiZGVmYXVsdFByb3BzIiwiSW5uZXJiYW5uZXIiLCJiYWNrZ3JvdW5kSW1hZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLE1BQU1BLFNBQVMsR0FBRyxFQUFsQjtBQUNBLE1BQU1DLFlBQVksR0FBRyxFQUFyQjs7QUFFQSxNQUFNQyxXQUFXLEdBQUcsTUFBTTtBQUN0QixzQkFDSTtBQUFBLDJCQUNEO0FBQVMsUUFBRSxFQUFDLFlBQVo7QUFBeUIsZUFBUyxFQUFDLHFDQUFuQztBQUF5RSxXQUFLLEVBQUU7QUFBQ0MsdUJBQWUsRUFBRztBQUFuQixPQUFoRjtBQUFBLDZCQUNKO0FBQUssaUJBQVMsRUFBQyxvQkFBZjtBQUFBLGdDQUNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURELGVBRUM7QUFBQSw4RUFBNEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZELGVBR0M7QUFBSSxtQkFBUyxFQUFDLFlBQWQ7QUFBQSxrQ0FDQztBQUFJLHFCQUFTLEVBQUMsaUJBQWQ7QUFBQSxtQ0FBZ0M7QUFBRyxrQkFBSSxFQUFDLEdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERCxlQUVDO0FBQUkscUJBQVMsRUFBQyxpQkFBZDtBQUFBLG1DQUFnQztBQUFHLGtCQUFJLEVBQUMsR0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZELGVBR0M7QUFBSSxxQkFBUyxFQUFDLGlCQUFkO0FBQUEsbUNBQWdDO0FBQUcsa0JBQUksRUFBQyxHQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEQsZUFJQztBQUFJLHFCQUFTLEVBQUMsd0JBQWQ7QUFBdUMsNEJBQWEsTUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQyxtQkFESjtBQWdCSCxDQWpCRDs7QUFtQkFELFdBQVcsQ0FBQ0YsU0FBWixHQUF3QkEsU0FBeEI7QUFDQUUsV0FBVyxDQUFDRCxZQUFaLEdBQTJCQSxZQUEzQjtBQUVBLCtEQUFlQyxXQUFmLEUiLCJmaWxlIjoiY29tcG9uZW50c19MYXlvdXRfSW5uZXJiYW5uZXJfanN4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JzsgXHJcbmNvbnN0IHByb3BUeXBlcyA9IHt9O1xyXG5jb25zdCBkZWZhdWx0UHJvcHMgPSB7fTtcclxuIFxyXG5jb25zdCBJbm5lcmJhbm5lciA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgIDxzZWN0aW9uIGlkPVwicGFnZS10aXRsZVwiIGNsYXNzTmFtZT1cInBhZ2UtdGl0bGUtcGFyYWxsYXggcGFnZS10aXRsZS1kYXJrXCIgc3R5bGU9e3tiYWNrZ3JvdW5kSW1hZ2U6IGB1cmwoXCJpbWcvYmFubmVycy9JbnZlc3RvcnMtQmFubmVyLUltZy5qcGdcIilgIH19ID5cclxuXHRcdFx0PGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgY2xlYXJmaXhcIj5cclxuXHRcdFx0XHQ8aDE+REVMSVZFUklORyBST0JVU1QgRklOQU5DSUFMUzwvaDE+IFxyXG5cdFx0XHRcdDxoNj5XZSBiZWxpZXZlIHRoYXQgZXhlY3V0aW9uIGlzIGV2ZXJ5dGhpbmcgPGJyLz5hbmQgYWx3YXlzIGNoYWxsZW5nZSBvdXJzZWx2ZXMgdG8gZGVsaXZlciBzdXBlcmlvciBwZXJmb3JtYW5jZTwvaDY+XHJcblx0XHRcdFx0PG9sIGNsYXNzTmFtZT1cImJyZWFkY3J1bWJcIj5cclxuXHRcdFx0XHRcdDxsaSBjbGFzc05hbWU9XCJicmVhZGNydW1iLWl0ZW1cIj48YSBocmVmPVwiI1wiPkhvbWU8L2E+PC9saT5cclxuXHRcdFx0XHRcdDxsaSBjbGFzc05hbWU9XCJicmVhZGNydW1iLWl0ZW1cIj48YSBocmVmPVwiI1wiPkludmVzdG9yczwvYT48L2xpPiBcclxuXHRcdFx0XHRcdDxsaSBjbGFzc05hbWU9XCJicmVhZGNydW1iLWl0ZW1cIj48YSBocmVmPVwiI1wiPlJlc3VsdHMsIFJlcG9ydHMgJiBQcmVzZW50YXRpb25zPC9hPjwvbGk+XHJcblx0XHRcdFx0XHQ8bGkgY2xhc3NOYW1lPVwiYnJlYWRjcnVtYi1pdGVtIGFjdGl2ZVwiIGFyaWEtY3VycmVudD1cInBhZ2VcIj5SZXN1bHRzIEFubm91bmNlbWVudHM8L2xpPlxyXG5cdFx0XHRcdDwvb2w+IFxyXG5cdFx0XHQ8L2Rpdj4gXHJcblx0XHQ8L3NlY3Rpb24+XHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59XHJcblxyXG5Jbm5lcmJhbm5lci5wcm9wVHlwZXMgPSBwcm9wVHlwZXM7XHJcbklubmVyYmFubmVyLmRlZmF1bHRQcm9wcyA9IGRlZmF1bHRQcm9wczsgXHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbm5lcmJhbm5lcjsiXSwic291cmNlUm9vdCI6IiJ9