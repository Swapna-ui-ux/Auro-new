(function() {
var exports = {};
exports.id = "pages/our-commitment";
exports.ids = ["pages/our-commitment"];
exports.modules = {

/***/ "./pages/our-commitment.js":
/*!*********************************!*\
  !*** ./pages/our-commitment.js ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layout_Innerbanner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Layout/Innerbanner */ "./components/Layout/Innerbanner.jsx");


var _jsxFileName = "C:\\Users\\Swapna\\Desktop\\June-works\\react-aurobindo\\pages\\our-commitment.js";


const propTypes = {};
const defaultProps = {};

const ourcommitment = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout_Innerbanner__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 11
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", {
      id: "content",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "content-wrap",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "container",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "row col-mb-50",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "col-12",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
                className: "head-title",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
                  children: "Our Commitment"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 19,
                  columnNumber: 9
                }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                  children: "Our commitment towards sustained excellence includes our efforts to benefit the communities we work with. We operate through charitable donations, volunteering and by building a responsible business that abides by an essential set of social and environmental policies."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 20,
                  columnNumber: 10
                }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                  children: "We collaborate with community groups to support public policies that promote economic and societal development, while respecting local cultures."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 21,
                  columnNumber: 10
                }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                  children: "Aurobindo\u2019s sustainability charter covers the following intervention areas:"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 22,
                  columnNumber: 10
                }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                  className: "listitems",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: "Promoting education"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 24,
                    columnNumber: 11
                  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: "Supporting preventive healthcare"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 25,
                    columnNumber: 11
                  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: "Eradicating hunger, poverty and malnutrition"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 11
                  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: "Making safe drinking water available"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 27,
                    columnNumber: 11
                  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: "Encouraging environment sustainability"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 28,
                    columnNumber: 11
                  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: "Sustaining ecological balance and conservation of natural resources"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 29,
                    columnNumber: 11
                  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: "Encouraging rural sports"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 30,
                    columnNumber: 11
                  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: "Setting up old-age homes"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 31,
                    columnNumber: 11
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 23,
                  columnNumber: 10
                }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
                  children: "As part of our societal commitment, we support neighbourhoods with educational aids for school children and construct toilets and facilities for the provision of safe drinking water. Our primary focus is to promote education, encourage good health, provide safe drinking water and support sanitation."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 10
                }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
                  children: "CSR Policy"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 35,
                  columnNumber: 11
                }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
                  className: "govrce_plcy",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      href: "",
                      target: "_blank",
                      rel: "noopener",
                      children: ["CSR Report", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                        className: "pull-right",
                        children: ["Download ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                          className: "fa fa-file-pdf-o"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 37,
                          columnNumber: 106
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 37,
                        columnNumber: 68
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 37,
                      columnNumber: 16
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 37,
                    columnNumber: 12
                  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                      href: "",
                      target: "_blank",
                      rel: "noopener",
                      children: ["CSR Policy", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                        className: "pull-right",
                        children: ["Download ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
                          className: "fa fa-file-pdf-o"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 38,
                          columnNumber: 106
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 38,
                        columnNumber: 68
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 38,
                      columnNumber: 16
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 38,
                    columnNumber: 12
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 36,
                  columnNumber: 11
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 18,
                columnNumber: 8
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 17,
              columnNumber: 7
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 6
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 5
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 4
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 3
    }, undefined)]
  }, void 0, true);
};

ourcommitment.propTypes = propTypes;
ourcommitment.defaultProps = defaultProps;
/* harmony default export */ __webpack_exports__["default"] = (ourcommitment);

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-dev-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, ["components_Layout_Innerbanner_jsx"], function() { return __webpack_exec__("./pages/our-commitment.js"); });
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yZWFjdC1hdXJvYmluZG8vLi9wYWdlcy9vdXItY29tbWl0bWVudC5qcyIsIndlYnBhY2s6Ly9yZWFjdC1hdXJvYmluZG8vZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovL3JlYWN0LWF1cm9iaW5kby9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIl0sIm5hbWVzIjpbInByb3BUeXBlcyIsImRlZmF1bHRQcm9wcyIsIm91cmNvbW1pdG1lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0EsTUFBTUEsU0FBUyxHQUFHLEVBQWxCO0FBQ0EsTUFBTUMsWUFBWSxHQUFHLEVBQXJCOztBQUdBLE1BQU1DLGFBQWEsR0FBRyxNQUFNO0FBQ3hCLHNCQUNJO0FBQUEsNEJBQ0UsOERBQUMsbUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUdOO0FBQVMsUUFBRSxFQUFDLFNBQVo7QUFBQSw2QkFDQztBQUFLLGlCQUFTLEVBQUMsY0FBZjtBQUFBLCtCQUNDO0FBQUssbUJBQVMsRUFBQyxXQUFmO0FBQUEsaUNBRUM7QUFBSyxxQkFBUyxFQUFDLGVBQWY7QUFBQSxtQ0FDQztBQUFLLHVCQUFTLEVBQUMsUUFBZjtBQUFBLHFDQUNDO0FBQUsseUJBQVMsRUFBQyxZQUFmO0FBQUEsd0NBQ0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREQsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSkYsZUFLRTtBQUFJLDJCQUFTLEVBQUMsV0FBZDtBQUFBLDBDQUNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURELGVBRUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRkQsZUFHQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFIRCxlQUlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUpELGVBS0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBTEQsZUFNQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFORCxlQU9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVBELGVBUUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBUkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUxGLGVBZUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBZkYsZUFpQkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBakJILGVBa0JHO0FBQUksMkJBQVMsRUFBQyxhQUFkO0FBQUEsMENBQ0M7QUFBQSwyQ0FBSTtBQUFHLDBCQUFJLEVBQUMsRUFBUjtBQUFXLDRCQUFNLEVBQUMsUUFBbEI7QUFBMkIseUJBQUcsRUFBQyxVQUEvQjtBQUFBLDREQUFvRDtBQUFNLGlDQUFTLEVBQUMsWUFBaEI7QUFBQSw2REFBc0M7QUFBRyxtQ0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURELGVBRUM7QUFBQSwyQ0FBSTtBQUFHLDBCQUFJLEVBQUMsRUFBUjtBQUFXLDRCQUFNLEVBQUMsUUFBbEI7QUFBMkIseUJBQUcsRUFBQyxVQUEvQjtBQUFBLDREQUFvRDtBQUFNLGlDQUFTLEVBQUMsWUFBaEI7QUFBQSw2REFBc0M7QUFBRyxtQ0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSE07QUFBQSxrQkFESjtBQTBDSCxDQTNDRDs7QUE2Q0FBLGFBQWEsQ0FBQ0YsU0FBZCxHQUEwQkEsU0FBMUI7QUFDQUUsYUFBYSxDQUFDRCxZQUFkLEdBQTZCQSxZQUE3QjtBQUVBLCtEQUFlQyxhQUFmLEU7Ozs7Ozs7Ozs7O0FDdERBLG1DOzs7Ozs7Ozs7OztBQ0FBLG1EIiwiZmlsZSI6InBhZ2VzL291ci1jb21taXRtZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JzsgIFxyXG5pbXBvcnQgSW5uZXJiYW5uZXIgZnJvbSAnLi4vY29tcG9uZW50cy9MYXlvdXQvSW5uZXJiYW5uZXInO1xyXG5jb25zdCBwcm9wVHlwZXMgPSB7fTtcclxuY29uc3QgZGVmYXVsdFByb3BzID0ge307XHJcblxyXG4gXHJcbmNvbnN0IG91cmNvbW1pdG1lbnQgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8SW5uZXJiYW5uZXI+PC9Jbm5lcmJhbm5lcj5cclxuICAgICAgICAgIHsvKiA8IS0tIENvbnRlbnQgLS0+ICovfVxyXG5cdFx0PHNlY3Rpb24gaWQ9XCJjb250ZW50XCI+XHJcblx0XHRcdDxkaXYgY2xhc3NOYW1lPVwiY29udGVudC13cmFwXCI+XHJcblx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cclxuXHJcblx0XHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cInJvdyBjb2wtbWItNTBcIj5cclxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJjb2wtMTJcIj5cclxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cImhlYWQtdGl0bGVcIj5cclxuXHRcdFx0XHRcdFx0XHRcdDxoMj5PdXIgQ29tbWl0bWVudDwvaDI+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxwPk91ciBjb21taXRtZW50IHRvd2FyZHMgc3VzdGFpbmVkIGV4Y2VsbGVuY2UgaW5jbHVkZXMgb3VyIGVmZm9ydHMgdG8gYmVuZWZpdCB0aGUgY29tbXVuaXRpZXMgd2Ugd29yayB3aXRoLiBXZSBvcGVyYXRlIHRocm91Z2ggY2hhcml0YWJsZSBkb25hdGlvbnMsIHZvbHVudGVlcmluZyBhbmQgYnkgYnVpbGRpbmcgYSByZXNwb25zaWJsZSBidXNpbmVzcyB0aGF0IGFiaWRlcyBieSBhbiBlc3NlbnRpYWwgc2V0IG9mIHNvY2lhbCBhbmQgZW52aXJvbm1lbnRhbCBwb2xpY2llcy48L3A+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxwPldlIGNvbGxhYm9yYXRlIHdpdGggY29tbXVuaXR5IGdyb3VwcyB0byBzdXBwb3J0IHB1YmxpYyBwb2xpY2llcyB0aGF0IHByb21vdGUgZWNvbm9taWMgYW5kIHNvY2lldGFsIGRldmVsb3BtZW50LCB3aGlsZSByZXNwZWN0aW5nIGxvY2FsIGN1bHR1cmVzLjwvcD5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PHA+QXVyb2JpbmRv4oCZcyBzdXN0YWluYWJpbGl0eSBjaGFydGVyIGNvdmVycyB0aGUgZm9sbG93aW5nIGludGVydmVudGlvbiBhcmVhczo8L3A+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDx1bCBjbGFzc05hbWU9XCJsaXN0aXRlbXNcIj5cclxuXHRcdFx0XHRcdFx0XHRcdFx0XHQ8bGk+UHJvbW90aW5nIGVkdWNhdGlvbjwvbGk+XHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0PGxpPlN1cHBvcnRpbmcgcHJldmVudGl2ZSBoZWFsdGhjYXJlPC9saT5cclxuXHRcdFx0XHRcdFx0XHRcdFx0XHQ8bGk+RXJhZGljYXRpbmcgaHVuZ2VyLCBwb3ZlcnR5IGFuZCBtYWxudXRyaXRpb248L2xpPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdDxsaT5NYWtpbmcgc2FmZSBkcmlua2luZyB3YXRlciBhdmFpbGFibGU8L2xpPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdDxsaT5FbmNvdXJhZ2luZyBlbnZpcm9ubWVudCBzdXN0YWluYWJpbGl0eTwvbGk+XHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0PGxpPlN1c3RhaW5pbmcgZWNvbG9naWNhbCBiYWxhbmNlIGFuZCBjb25zZXJ2YXRpb24gb2YgbmF0dXJhbCByZXNvdXJjZXM8L2xpPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdDxsaT5FbmNvdXJhZ2luZyBydXJhbCBzcG9ydHM8L2xpPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdDxsaT5TZXR0aW5nIHVwIG9sZC1hZ2UgaG9tZXM8L2xpPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8L3VsPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8cD5BcyBwYXJ0IG9mIG91ciBzb2NpZXRhbCBjb21taXRtZW50LCB3ZSBzdXBwb3J0IG5laWdoYm91cmhvb2RzIHdpdGggZWR1Y2F0aW9uYWwgYWlkcyBmb3Igc2Nob29sIGNoaWxkcmVuIGFuZCBjb25zdHJ1Y3QgdG9pbGV0cyBhbmQgZmFjaWxpdGllcyBmb3IgdGhlIHByb3Zpc2lvbiBvZiBzYWZlIGRyaW5raW5nIHdhdGVyLiBPdXIgcHJpbWFyeSBmb2N1cyBpcyB0byBwcm9tb3RlIGVkdWNhdGlvbiwgZW5jb3VyYWdlIGdvb2QgaGVhbHRoLCBwcm92aWRlIHNhZmUgZHJpbmtpbmcgd2F0ZXIgYW5kIHN1cHBvcnQgc2FuaXRhdGlvbi48L3A+XHJcblxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdDxoND5DU1IgUG9saWN5PC9oND5cclxuXHRcdFx0XHRcdFx0XHRcdFx0XHQ8dWwgY2xhc3NOYW1lPVwiZ292cmNlX3BsY3lcIj5cclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdDxsaT48YSBocmVmPVwiXCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXJcIj5DU1IgUmVwb3J0PHNwYW4gY2xhc3NOYW1lPVwicHVsbC1yaWdodFwiPkRvd25sb2FkIDxpIGNsYXNzTmFtZT1cImZhIGZhLWZpbGUtcGRmLW9cIj48L2k+PC9zcGFuPjwvYT48L2xpPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0PGxpPjxhIGhyZWY9XCJcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiPkNTUiBQb2xpY3k8c3BhbiBjbGFzc05hbWU9XCJwdWxsLXJpZ2h0XCI+RG93bmxvYWQgPGkgY2xhc3NOYW1lPVwiZmEgZmEtZmlsZS1wZGYtb1wiPjwvaT48L3NwYW4+PC9hPjwvbGk+XHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0PC91bD5cdCAgXHJcblx0XHRcdFx0XHRcdFx0PC9kaXY+IFxyXG5cdFx0XHRcdFx0XHQ8L2Rpdj4gIFxyXG5cdFx0XHRcdFx0PC9kaXY+XHJcblxyXG5cdFx0XHRcdDwvZGl2PlxyXG5cdFx0XHQ8L2Rpdj5cclxuXHRcdDwvc2VjdGlvbj5cclxuXHRcdHsvKiA8IS0tICNjb250ZW50IGVuZCAtLT4gKi99XHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59XHJcblxyXG5vdXJjb21taXRtZW50LnByb3BUeXBlcyA9IHByb3BUeXBlcztcclxub3VyY29tbWl0bWVudC5kZWZhdWx0UHJvcHMgPSBkZWZhdWx0UHJvcHM7XHJcbiBcclxuZXhwb3J0IGRlZmF1bHQgb3VyY29tbWl0bWVudDsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOzsiXSwic291cmNlUm9vdCI6IiJ9