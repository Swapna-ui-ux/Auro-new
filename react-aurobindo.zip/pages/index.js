import Head from 'next/head'
import Image from 'next/image'
import Banner from '../components/Banner'
import Commited from '../components/Home/Commited'


export default function Home() {
  return (
    <>
   <Banner></Banner>
   <Commited></Commited>
    </>
  )
}
