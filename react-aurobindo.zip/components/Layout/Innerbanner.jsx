import React from 'react'; 
const propTypes = {};
const defaultProps = {};
 
const Innerbanner = () => {
    return (
        <>
       <section id="page-title" className="page-title-parallax page-title-dark" style={{backgroundImage: `url("img/banners/Investors-Banner-Img.jpg")` }} >
			<div className="container clearfix">
				<h1>DELIVERING ROBUST FINANCIALS</h1> 
				<h6>We believe that execution is everything <br/>and always challenge ourselves to deliver superior performance</h6>
				<ol className="breadcrumb">
					<li className="breadcrumb-item"><a href="#">Home</a></li>
					<li className="breadcrumb-item"><a href="#">Investors</a></li> 
					<li className="breadcrumb-item"><a href="#">Results, Reports & Presentations</a></li>
					<li className="breadcrumb-item active" aria-current="page">Results Announcements</li>
				</ol> 
			</div> 
		</section>
        </>
    );
}

Innerbanner.propTypes = propTypes;
Innerbanner.defaultProps = defaultProps; 

export default Innerbanner;